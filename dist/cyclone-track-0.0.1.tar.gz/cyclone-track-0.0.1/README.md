# INDEX
- [ABOUT](#ABOUT)
- [HOWTOUSE](#HOWTOUSE)
- [ENVIRONMENT](#ABOUT)
- [INSTALATION](#INSTALATION)

# ABOUT
- Track cyclone center position.
- This project is created as [爆弾低気圧データベース](http://fujin.geo.kyushu-u.ac.jp/meteorol_bomb/algorithm/index.php) and [pytrack](https://github.com/tenomoto/pytrack)
## Algorithm

### 1. Find cyclone formation position and datetime.
1. Find local minima by scipy.ndimage.filters.minimum_filter() assuming a cyclic boundary conditon in longitude.
2. Find the grid of the minimum closest to the initial guess lat lon(seted by stdin). This minimum is candidate of cyclone center.
3. If cyclone center presure is 0.5 hPa less than around area pressure, define it low pressure and continue 1,2 step for 6h ago's data. If cannot find low pressure, define cyclone formation datetime is 6h ago.
### 2. Track cyclone
1. Find local minima by scipy.ndimage.filters.minimum_filter() assuming a cyclic boundary conditon in longitude.
2. Find the grid of the minimum closest to the initial guess lat lon(seted by stdin). This minimum is candidate of cyclone center.
3. Generate nine point stencil with the minimum on grid at the centre
4. Interpolate for the minimum in-between grid using biquadratic interpolation. If interpolation fails use the minimum on grid


# HOWTOUSE

```shell
python3 -m cyclonetrack -x 135 -y 37 --dir ~/data_ini/prmsl -t 2021-01-06_12
```

# INSTALATION
## build from source cord.

```shell
git clone https://github.com/RyosukeDTomita/cyclone_track.git
cd cyclone_track
python3 setup.py install
```

# ENVIRONMENT
I tested the following environment.
- Python3.8
- Ubuntu 20.04 LTS
see [requirement.txt](./requirements.txt)
