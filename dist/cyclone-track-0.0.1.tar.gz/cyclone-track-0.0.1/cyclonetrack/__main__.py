import cyclonetrack


if __name__ == "__main__":
    cyclonetrack.main()
